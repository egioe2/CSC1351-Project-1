package prog01_aorderedlist;

/**
* Class used to create comparable Car objects and retrieve their information.
* 
* CSC 1351 Programming Project No 1
* Section 2
* 
* @author Eric Gioe
* @since 3/17/24
*
*/
public class Car implements Comparable<Car>
{
    private String make;                                                        //Parameter specifying the model of the Car object.
    private int year;                                                           //Parameter specifying the year in which the Car object was made.
    private int price;                                                          //Parameter specifying the price of the Car object.
    
    /**
    * Constructor method for Car objects.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public Car(String Make, int Year, int Price)
    {
        make = Make;
        year = Year;
        price = Price;
    }
    
    /**
    * Method for returning make parameter.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public String getMake()
    {
        return make;
    }
    
    /**
    * Method for returning year parameter.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public int getYear()
    {
        return year;
    }
    
    /**
    * Method for returning price parameter.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public int getPrice()
    {
        return price;
    }
    
    /**
    * Method specifying how Car objects are compared to each other.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    @Override
    public int compareTo(Car other)
    {
        //Compare by make year if make is equal
        if(make.compareTo(other.make) == 0)
        {
            return Integer.compare(year, other.year);
        }
        
        //If makes are not equal, compare by make
        else
        {
            return make.compareTo(other.make);
        }
    }
    
    /**
    * Method that returns Car object information in a formatted String.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    @Override
    public String toString()
    {
        return("Make: " + make + ", Year: " + year + ", Price: " + price + ";");
    }
}
