package prog01_aorderedlist;

import java.lang.reflect.Array;
import java.util.Arrays;

/**
* Class used to create an ordered list of any specified Comparable object
* type that is sorted upon the addition of new objects and can delete previously
* added objects. Can return the size of the list and individual objects. Can see 
* whether or not the list is empty. Can return information of objects in a list 
* in a formatted String. Has an iterator that can perform deletion and check if 
* there are further objects to iterate through.
* 
* CSC 1351 Programming Project No 1
* Section 2
* 
* @author Eric Gioe
* @since 3/17/24
*
*/
public class aOrderedList<T extends Comparable>                                 
{
    final int SIZEINCREMENTS = 20;                                              //Specifies the size of the increments increasing the oList array length.
    
    private T[] oList;                                                          //Used to store Comparable objects.
    private int listSize;                                                       //Specifies the current size of the list.
    private int numObjects;                                                     //Specifies the current number of objects in the list.
    private int increments;                                                     //Specifies how many increments have been made to add on to the original array.
    private int curr = -1;                                                      //Specifies current index of iterator.
    private int last = -1;                                                      //Specifies last index of iterator used by next() method.
    
    /**
    * Constructor method for ordered list. Takes an object that is the same type
    * as the desired object type of the array.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public aOrderedList(T defVal)
    { 
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        
        //Create array oList of same class type as defVal parameter
        oList = (T[]) Array.newInstance(defVal.getClass(),SIZEINCREMENTS); 
        increments = 1;
    }
    
    /**
    * Adds an object of type T to the ordered list.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public void add(T newObject)
    {
        //Add to numObjects when add is called
        numObjects++;
        
        //If numObjects goes over current array size, increment array size by 20
        if(numObjects > SIZEINCREMENTS * increments)
        {
            increments++;
            listSize = SIZEINCREMENTS * increments;
            
            T[] newList = Arrays.copyOf(oList, listSize);
            oList = newList;
        }
        //Move objects down array before adding new object
        System.arraycopy(oList, 0, oList, 1, numObjects-1);
        
        oList[0] = newObject;
        
        //Sort array
        Arrays.sort(oList, 0, numObjects);
    }
    
    /**
    * Returns list object information in formatted String.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    @Override
    public String toString()
    {
        String list = "";                                                       //Used to add different list objects' information together in String form.
        
        //Add list object information in String form to previous list objects
        //separated by commas
        for(int i=0; i<numObjects; i++)
        {
            list = list + "[" + oList[i].toString() + "],";
        }
        
        //Remove final list object's String's comma
        list = list.substring(0,list.length()-1);
        return list;
    }
    
    /**
    * Returns amount of objects currently in oList array.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public int size()
    {
        return numObjects;
    }
    
    /**
    * Return specific object in list specified by said object's index.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    T get(int index)
    {
        return oList[index];
    }
    
    
    /**
    * Checks if the array is empty.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public boolean isEmpty()
    {
        //If no objects have been added, array is empty
        boolean empty = false;
        if(numObjects == 0)
        {
            empty = true;
        }
        
        //Otherwise, array is not empty
        else
        {
            empty = false;
        }
        return empty;
    }
    
    /**
    * Using an index value as a parameter, remove an object from the list.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public void remove(int index)
    {
        //Shift objects up the list to replace removed object
        for(int i = index; i < numObjects; i++)
        {
            oList[i] = oList[i+1];
        }
        
        //Remove copy of last object in list that is in last position
        oList[numObjects-1] = null;
        
        //Subtract deleted object from counter
        numObjects--;
    }
    
    /**
    * Resets the current position of the iterator to before the first object in 
    * the array.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public void reset()
    {
        curr = -1;
    }
    
    /**
    * Returns the object located directly after the current position of the
    * iterator and moves the iterator's position forward by one.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public T next()
    {
        curr++;
        last = curr;
        return oList[curr];
    }
    
    /**
    * Checks if the position after the iterator's current position contains an
    * object.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public boolean hasNext()
    {
        if(curr < numObjects)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /**
    * Removes the object last returned by next() method.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public void remove()
    {
        try
            
        //Remove object at index last used by next() by replacing it with values 
        //further down
        {
        for(int i = last; i < numObjects; i++)
        {
            oList[i] = oList[i+1];
        }
        
        //Delete copy of last object in list
        oList[numObjects-1] = null;
        
        //Subtract deleted object from counter
        numObjects--;
        }
        catch(Exception e)
        {
            //Inform user that remove() failed
            System.out.println("remove() removes the last element returned "
                + "by next(). You are seeing this because remove() was called "
                + "when next() has not yet been called.");
        }
    }        
}
