package prog01_aorderedlist;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;

/**
* Class containing main method and methods for interacting with input/output 
* files.
* 
* CSC 1351 Programming Project No 1
* Section 2
* 
* @author Eric Gioe
* @since 3/17/24
*
*/
public class Prog01_aOrderedList 
{   
    /**
    * Main method that takes in a user specified file containing operations and 
    * information for Car objects, reads it, constructs an object for each line 
    * of information, puts them into an array, sorts them with each operation, 
    * and outputs the objects' data in a specific format to another user 
    * specified file.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public static void main(String[] args) throws FileNotFoundException
    {   
        Scanner inFile;                                                         //Copies value of getInputFile method to read through the input file and
                                                                                //store info from it to other variables.
        PrintWriter outFile;                                                    //Copies value of getOutputFile method to write to the output file.
        String line;                                                            //Stores each line of the input file to break it down into different pieces
                                                                                //of data for the Car objects.
        String function;                                                        //Stores part of line to specify what operation needs to occur
        String make;                                                            //Stores part of line to indicare what each Car object's make parameter is
        String yearString;                                                      //Stores part of line to be converted to int for year
        String priceString;                                                     //Stores part of line to be converted to int for price
        int year;                                                               //Converted yearString to indicare what each Car object's year parameter is
        int price;                                                              //Converted priceString to indicare what each Car object's price parameter is
        int index;                                                              //Converted part of line to indicate the index to be deleted when function
                                                                                //equals "D" and only a number is given after the operation.
        Car newCar;                                                             //Used to create and add each Car object in the array of aOrderedList carList.
        Car defCar = new Car("",0,0);                                           //Used to specify the type of class used in carList.
        NumberFormat nf = NumberFormat.getCurrencyInstance();                   //Used to add formatting to text written to output file.
        
        //Create aOrderedList object to store list of Car objects
        aOrderedList<Car> carList = new aOrderedList(defCar);                   
        
        //Create an instance of the class so there is no exception when calling non static methods to the static main method
        Prog01_aOrderedList a = new Prog01_aOrderedList();                      
        
        inFile = a.GetInputFile("Enter input file name: ");
        outFile = a.GetOutputFile("Enter output file name: ");
 
        while(inFile.hasNextLine())                                             
        {
            //Assign each line from file to variable for breakdown into operation using commas as borders
            line = inFile.nextLine();
            function = line.substring(0,1);
            line = line.substring(2,line.length());
            
            //Determine operation to be carried out using value of function variable
            if(function.equals("A"))
            {
                //Break down line further and assign values to parameter variables using commas as borders
                make = line.substring(0,line.indexOf(','));
                line = line.substring(line.indexOf(',')+1,line.length());
                yearString = line.substring(0,line.indexOf(','));
                line = line.substring(line.indexOf(',')+1,line.length());
                priceString = line;
                
                //Convert String versions of int paramters to int
                year = Integer.parseInt(yearString);
                price = Integer.parseInt(priceString);
                
                //Use parameters to construct Car objects; add to carList
                newCar = new Car(make, year, price); 
                carList.add(newCar);
            }
            else if(function.equals("D"))
            {
                //Delete via year/make parameters if specified in input file
                try
                {
                    make = line.substring(0,line.indexOf(','));
                    line = line.substring(line.indexOf(',')+1,line.length());
                    yearString = line;

                    year = Integer.parseInt(yearString);

                    for(int i = 0; i < carList.size(); i++)
                    {
                        if(carList.get(i).getMake().equals(make) && 
                            carList.get(i).getYear() == year)
                        {
                            carList.remove(i);
                        }
                    }
                }
                //Delete via index if only a number is after operation in line
                catch(Exception e)
                {
                    index = Integer.parseInt(line);
                    carList.remove(index);
                }
            }
        }   
        
        //Print formatted objects from carList to output file
        outFile.printf("Number of cars:%8d\n\n", carList.size());
        for(int i = 0; i < carList.size(); i++)
        {
            outFile.printf("Make:%10s\n", carList.get(i).getMake());
            outFile.printf("Year:%10d\n", carList.get(i).getYear());
            outFile.printf("Price:%9s\n\n", nf.format(carList.get(i).getPrice()
                ).substring(0,nf.format(carList.get(i).getPrice()).length()-3));
        }
        
        outFile.close();
        inFile.close();
    }
    
    /**
    * Method that returns a Scanner object that can read through a user 
    * specified input file.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public Scanner GetInputFile(String UserPrompt) throws FileNotFoundException
    {
        String fileName;                                                        //Stores name of user specified input file.
        String again;                                                           //Used as a check for user input verification when input file name is invalid.
        Scanner in = new Scanner(System.in);                                    //Used to prompt user for file name.
        Scanner inFile;                                                         //Object that is returned for input file reading when an attempt at entering 
                                                                                //file name fails.
        File inputFile;                                                         //Refers to actual file indicated by user input; read by Scanner that is returned.
       
        //Prompt user for file name
        System.out.print(UserPrompt);
        fileName = in.nextLine();

        //Attempt to construct file using input
        try
        {
            inputFile = new File(fileName);
            return new Scanner(inputFile);
        }
        
        //When input fails due to FileNotFoundException, ask user if they wish to continue
        catch(FileNotFoundException e)
        { 
            System.out.print("File specified <" + fileName + "> does not "
                    + "exist. Enter Y if you wish to continue or anything else "
                    + "to quit: ");
            again = in.nextLine();
            
            //When user continues, prompt for file name again
            if(again.equals("Y"))
            {
                inFile = GetInputFile("Enter input file name: ");
            }
            
            //When user quits, throw FileNotFoundException
            else
            {
                throw e;
            }
            return inFile;
        }
    }
    
    /**
    * Method that returns a PrintWriter object capable of writing to a user
    * specified output file.
    * 
    * CSC 1351 Programming Project No 1
    * Section 2
    * 
    * @author Eric Gioe
    * @since 3/17/24
    *
    */
    public PrintWriter GetOutputFile(String UserPrompt) throws 
            FileNotFoundException
    {
        String fileName;                                                        //Stores name of user specified input file.
        String again;                                                           //Used as a check for user input verification when input file name is invalid.
        Scanner in = new Scanner(System.in);                                    //Used to prompt user for file name.
        PrintWriter outputFile;                                                 //Refers to actual file indicated by user input.
        PrintWriter outFile;                                                    //Object that is returned for output file writing when an attempt at entering 
                                                                                //file name fails.
       
        //Prompt user for file name
        System.out.print(UserPrompt);
        fileName = in.nextLine();
        
        //Attempt to construct file using input
        try
        {
            outputFile = new PrintWriter(fileName);
            return new PrintWriter(outputFile);
        }
        
        //When input fails due to FileNotFoundException, ask user if they wish to continue
        catch(FileNotFoundException e)
        { 
            System.out.print("File specified <" + fileName + "> does not exist."
                    + " Enter Y if you wish to continue or anything else to "
                    + "quit: ");
            again = in.nextLine();
            
            //When user continues, prompt for file name again
            if(again.equals("Y"))
            {
                outFile = GetOutputFile("Enter output file name: ");
            }
            
            //When user quits, throw FileNotFoundException
            else
            {
                throw e;
            }
            return outFile;
        }
    }
}
    
